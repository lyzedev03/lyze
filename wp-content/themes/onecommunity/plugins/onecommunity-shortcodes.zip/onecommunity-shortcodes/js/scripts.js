jQuery(function(){

    jQuery('.shortcode-bp-groups-tabs-container #object-nav ul li').click(function(){
    jQuery( '.shortcode-bp-groups-tabs-container #object-nav ul li.current' ).removeClass( 'current' );
    jQuery( '.load-more-groups' ).removeClass( 'no-more' );
    jQuery(this).addClass( 'current' );

    var groups_type = jQuery(this).attr('data-tab');
    var per_page = jQuery(this).attr('data-tab-per-page');
    var page = jQuery(this).attr('data-tab-page');
    var nonce = jQuery(this).attr("data-nonce");


// Update attributes of load more button
        jQuery(".load-more-groups").attr("data-tab", groups_type);
        jQuery(".load-more-groups").attr("data-tab-per-page", per_page);
        jQuery(".load-more-groups").attr("data-tab-page", page);

        jQuery.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {
                action:'onecommunity_bp_groups_listing_load',
                'groups_type': groups_type,
                'per_page': per_page,
                'page': page,
                'nonce': nonce
            },
            success:function(data) {

                jQuery( ".shortcode-bp-groups-tabs-container .list-wrap ul" ).empty();

                var length = jQuery(data).filter('li').length;
                  if(length < per_page) {
                    jQuery( ".load-more-groups" ).addClass( "no-more" ).fadeOut();
                  }

                jQuery( ".shortcode-bp-groups-tabs-container .list-wrap ul" ).append(data).hide().fadeIn(500);

            },
            error: function(errorThrown){
                jQuery( ".shortcode-bp-groups-tabs-container .list-wrap ul" ).append( "Data error" );
                console.log(errorThrown);
            }
        }); 

    }); 




    jQuery('.load-more-groups').click(function () {

    var groups_type = jQuery(this).attr('data-tab');
    var per_page = jQuery(this).attr('data-tab-per-page');
    var nonce = jQuery(this).attr("data-nonce");
    var page = jQuery(this).attr('data-tab-page');
    var page_next = Number(page) + 1;
    jQuery(".load-more-groups").attr("data-tab-page", page_next);

        jQuery.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {
                action:'onecommunity_bp_groups_listing_load',
                'groups_type': groups_type,
                'per_page': per_page,
                'page': page_next,
                'nonce': nonce
            },
            success:function(data) {
                var length = jQuery(data).filter('li').length;
                if(data === ''){ 
                    jQuery( ".load-more-groups" ).addClass( "no-more" ).fadeOut();
                } else if (length < per_page) {
                    jQuery( ".load-more-groups" ).addClass( "no-more" ).fadeOut();
                }

                jQuery( ".shortcode-bp-groups-tabs-container .list-wrap ul" ).append(data);

            },
            error: function(errorThrown){
                jQuery( ".shortcode-bp-groups-tabs-container .list-wrap ul" ).append( "Data error" );
                console.log(errorThrown);
            }
        });

    });



});



///////////////////////////////////////////////////////////////////////////////////////////////


jQuery(function(){
"use strict";

    jQuery('.shortcode-posts-tabs-container #object-nav ul li').click(function(){
    jQuery( '.shortcode-posts-tabs-container #object-nav ul li' ).removeClass( 'current' );
    jQuery( '.load-more-posts' ).removeClass( 'no-more' );
    jQuery(this).addClass( "current" );

    var blog_posts_type = jQuery(this).attr('data-tab');
    var number_of_posts = jQuery(this).attr('data-tab-per-page');
    var page = jQuery(this).attr('data-tab-page');
    var nonce = jQuery(this).attr("data-nonce");


    // Update attributes of load more button
        jQuery(".load-more-posts").attr("data-tab", blog_posts_type);
        jQuery(".load-more-posts").attr("data-tab-per-page", number_of_posts);
        jQuery(".load-more-posts").attr("data-tab-page", page);

        jQuery.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {
                action:'onecommunity_blog_posts_tabs_load',
                'blog_posts_type': blog_posts_type,
                'number_of_posts': number_of_posts,
                'page': page,
                'nonce': nonce
            },
            success:function(data) {
                jQuery( ".shortcode-posts-tabs-container .blog-posts-tabs-load" ).empty();

                var length = jQuery(data).filter('li').length;
                if(length == number_of_posts) {
                    jQuery( ".load-more-posts" ).addClass( "show" ).fadeIn();
                }

                if(length < number_of_posts) {
                    jQuery( ".load-more-posts" ).removeClass( "show" ).fadeOut();
                }   

                jQuery( ".shortcode-posts-tabs-container .blog-posts-tabs-load" ).append(data).hide().fadeIn(500);

                var $container = jQuery('.blog-posts-tabs-load');
                    $container.masonry({
                      itemSelector: '.blog-thumbs-view-entry'
                   });

                   $container.imagesLoaded().progress( function() {
                     $container.masonry();
                });


            },
            error: function(errorThrown){
                jQuery( ".shortcode-posts-tabs-container .blog-posts-tabs-load" ).append( "Data error" );
                console.log(errorThrown);
            }
        }); 

    }); 




    jQuery('.load-more-posts').click(function () {

    var blog_posts_type = jQuery(this).attr('data-posts-type');
    var number_of_posts = jQuery(this).attr('data-tab-per-page');
    var page = jQuery(this).attr('data-tab-page');
    var nonce = jQuery(this).attr("data-nonce");
    var page_next = Number(page) + 1;
    jQuery(".load-more-posts").attr("data-tab-page", page_next);

        jQuery.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {
                action:'onecommunity_blog_posts_tabs_load',
                'blog_posts_type': blog_posts_type,
                'number_of_posts': number_of_posts,
                'page': page_next,
                'nonce': nonce
            },
            success:function(data) {

                var length = jQuery(data).filter('li').length;
                if(length == number_of_posts) {
                    jQuery( ".load-more-posts" ).addClass( "show" ).fadeIn();
                }

                if(length < number_of_posts) {
                    jQuery( ".load-more-posts" ).removeClass( "show" ).fadeOut();
                }                

                jQuery( ".shortcode-posts-tabs-container .blog-posts-tabs-load" ).append(data).masonry( 'reloadItems' );

                    var $container = jQuery('.blog-posts-tabs-load');
                    $container.masonry({
                      itemSelector: '.blog-thumbs-view-entry'
                    });

                    $container.imagesLoaded().progress( function() {
                    $container.masonry();
                    });     

            },
            error: function(errorThrown){
                jQuery( ".shortcode-posts-tabs-container .blog-posts-tabs-load" ).append( "Data error" );
                console.log(errorThrown);
            }
        });

    });


});


///////////////////////////////////////////////////////////////////////////////////////////////

jQuery(function(){

var $container = jQuery('.blog-posts-tabs-load');

$container.masonry({
  itemSelector: '.blog-thumbs-view-entry'
});

$container.imagesLoaded().progress( function() {
  $container.masonry();
});

});

///////////////////////////////////////////////////////////////////////////////////////////////

jQuery(function(){
var $container = jQuery('.recent-comment-container');
// initialize
$container.masonry({
  itemSelector: '.shordcode-recent-comment'
});
});

///////////////////////////////////////////////////////////////////////////////////////////////


