<?php
if (!defined('ABSPATH')) die('-1');

require_once(ASP_CLASSES_PATH . "cache/bfi_thumb.php");
require_once(ASP_CLASSES_PATH . "cache/textcache.class.php");