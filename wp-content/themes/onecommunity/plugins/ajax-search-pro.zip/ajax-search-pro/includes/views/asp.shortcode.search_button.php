<?php if ( $_st['fe_search_button'] == 1 ): ?>
    <fieldset class="asp_s_btn_container">
        <button class="asp_search_btn asp_s_btn"><?php echo asp_icl_t('Search button ('.$real_id.')', $_st['fe_sb_text']); ?></button>
    </fieldset>
<?php endif; ?>